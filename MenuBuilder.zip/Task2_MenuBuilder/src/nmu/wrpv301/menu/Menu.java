package nmu.wrpv301.menu;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu {

    private String title;
    private final List<MenuItem> items = new ArrayList<>();

    public Menu(String title) {
        this.title = title;
    }

    public void add(String text, Runnable action) {
        items.add(new MenuItem(text, action));
    }

    public void add(String text, Menu submenu) {
        items.add(new MenuItem(text, submenu));
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== " + title + " ===");
            for (int i = 0; i < items.size(); i++) {
                System.out.printf("%d. %s%n", i + 1, items.get(i).text);
            }
            System.out.println("0. Exit");

            System.out.print("Choice: ");
            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input.");
                continue;
            }

            if (choice == 0) break;

            if (choice >= 1 && choice <= items.size()) {
                MenuItem item = items.get(choice - 1);
                if (item.submenu != null) {
                    item.submenu.run();
                } else if (item.action != null) {
                    item.action.run();
                }
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    private static class MenuItem {
        String text;
        Runnable action;
        Menu submenu;

        MenuItem(String text, Runnable action) {
            this.text = text;
            this.action = action;
        }

        MenuItem(String text, Menu submenu) {
            this.text = text;
            this.submenu = submenu;
        }
    }
}