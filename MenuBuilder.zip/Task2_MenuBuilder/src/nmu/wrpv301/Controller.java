package nmu.wrpv301;

public class Controller {

    public void whatIsYourNameAction() {
        System.out.println("My name is Hamlet!");
    }

    public void helloWorldAction() {
        System.out.println("Hello, world!");
    }

    public void fiveTimesTableAction() {
        for (int i = 1; i <= 10; i++)
            System.out.println("5 x " + i + " = " + (5 * i));
    }

    public void isPrimeAction() {
        System.out.println("13 is prime.");
    }

    public void isOddAction() {
        System.out.println("7 is odd.");
    }
}