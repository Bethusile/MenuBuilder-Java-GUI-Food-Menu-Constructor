package nmu.wrpv301;

import nmu.wrpv301.menu.Menu;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.lang.reflect.Method;

public class MenuBuilderUtil {

    public static Menu build(String xmlFilePath) {
        try {
            Document doc = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder()
                    .parse(new File(xmlFilePath));
            doc.getDocumentElement().normalize();

            Element root = doc.getDocumentElement();

            String controllerClassName = root.getAttribute("controller");
            String menuTitle = root.getAttribute("title");

            Class<?> controllerClass = Class.forName(controllerClassName);
            Object controllerInstance = controllerClass.getDeclaredConstructor().newInstance();

            return buildMenu(root, controllerInstance, menuTitle);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static Menu buildMenu(Element element, Object controller, String title) throws Exception {
        Menu menu = new Menu(title);

        NodeList children = element.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node instanceof Element) {
                Element child = (Element) node;
                String tag = child.getTagName();

                if (tag.equals("choice")) {
                    String text = child.getAttribute("text");
                    String action = child.getAttribute("action");

                    Method method = controller.getClass().getMethod(action);
                    menu.add(text, () -> {
                        try {
                            method.invoke(controller);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    });

                } else if (tag.equals("submenu")) {
                    String subText = child.getAttribute("text");
                    String subTitle = child.getAttribute("action");

                    Menu subMenu = buildMenu(child, controller, subTitle);
                    menu.add(subText, subMenu);
                }
            }
        }

        return menu;
    }
}