package nmu.wrpv301;

import nmu.wrpv301.menu.Menu;

public class Main {
    public static void main(String[] args) {
        Menu menu = MenuBuilderUtil.build("src/nmu/wrpv301/menu.xml");
        if (menu != null) {
            menu.run();
        }
    }
}